# AKSARA Android Native Wrapper — v2.0.0

Private offline literary workspace. No account and no INTERNET permission. WebView loads the app from bundled assets; works offline. User content uses WebView local storage, so periodically export backup.

## Build APK with Android Studio
1. Install Android Studio on a computer (Windows/macOS/Linux) and Android SDK Platform 35 + Build Tools.
2. Extract this ZIP, open the `aksara_native` folder in Android Studio (File > Open).
3. Allow Gradle sync and install the required Android Gradle Plugin (8.7.3) if prompted. Requires internet during first setup.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. After build completes, use the notification link or locate `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to Android, tap it, allow installation from that source if Android prompts, then install.

For release builds, create a signed APK from Build > Generate Signed Bundle / APK. Keep the signing key private.

## Included native support
- Android WebView offline shell with local assets
- JavaScript enabled and local DOM storage
- Clipboard integration
- Native JSON backup file picker (Save As)
- Import file chooser
- Android launcher icon
- No internet permission, no analytics, no login

## Test notes
- JavaScript syntax checked using Node.js `--check`.
- Duplicate HTML IDs checked: none found.
- This source project has not been compiled or run on a physical Android device or emulator in this environment. No software can honestly promise zero bugs; device testing and review are still required before treating it as bug-free.
